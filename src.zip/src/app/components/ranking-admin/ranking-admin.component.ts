import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ranking-admin',
  templateUrl: './ranking-admin.component.html',
  styleUrls: ['./ranking-admin.component.css']
})
export class RankingAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
